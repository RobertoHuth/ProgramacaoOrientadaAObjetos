import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);

        System.out.println("------Jogo da Forca------");
        System.out.println("");

        System.out.println("Tente acertar a palavra!");
        String palavra = "dinossauro";
        System.out.println("");
        String palavraEscondida = "----------";
        
        boolean acertou = false;
        int chances = 5;
        

        while(true)
        {
            System.out.println("Palavra secreta: "+palavraEscondida);
            System.out.println("Você tem "+chances+ " chances");
            System.out.println("Informe uma letra:");
            String letra = scnr.nextLine();
            acertou = palavra.contains(letra);
            System.out.println("");
            if(acertou)
            {
                System.out.println("Você acertou uma letra! Continue!");
                int indice = palavra.indexOf(letra);
                while(indice >= 0)
                {
                    palavraEscondida = palavraEscondida.substring(0,indice)
                            +letra
                            +palavraEscondida.substring(indice+1);
                    indice = palavra.indexOf(letra,indice+1);
                }
                if(!palavraEscondida.contains("-"))
                {
                    System.out.println("Você acertou a palavra! Parabéns");
                    break;
                }
            }else
            {
                System.out.println("Você errou uma letra!");
                chances--;
                if(chances == 0)
                {
                    System.out.println("Você perdeu o jogo!");
                    break;
                }
            }
        }
    }

}
