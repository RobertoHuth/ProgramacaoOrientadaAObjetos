import java.util.Scanner;

  public class Main{
    public static void main(String[] args) {
      Scanner scn = new Scanner(System.in);
      int linha, colunas= 0;

      System.out.print("Quantas Linhas e Colunas terá a Matrix? ");
      colunas = scn.nextInt();
      linha = colunas;

      int matrix[][] = new int[linha][colunas];

      System.out.println("Informe os elementos da matriz --> ");
      for(int i=0;i<linha;i++){
        System.out.print("Informe os elementos da linha "+(i+1)+": ");
        for(int j=0;j<colunas;j++){
          matrix[i][j] = scn.nextInt();
        }
      }

      for(int r[] : matrix){
        for(int element : r){
          System.out.print(element+" ");
        } 
        System.out.println();
      }
    
      rodar(matrix);
    }  

    public static void rodar(int[][] matrix){
      Scanner scn = new Scanner(System.in);
      int N = matrix.length;
      int dgree = 0;

      System.out.print("Quantos graus desejas rotacionar sua matrix? (0°, 90°, 180°, 270° e 360°)");
      dgree = scn.nextInt();

      switch(dgree){
        case 0:
          for(int r[] : matrix){
            for(int element : r){
              System.out.print(element+" ");
            }
            System.out.println();
          }
          break;

        case 90:
          for(int i=0;i<N;i++){
            for(int j=i; j<N; j++){
              int aux = matrix[i][j];
              matrix[i][j] = matrix[j][i];
              matrix[j][i] = aux;
            }
          }
          for(int i=0;i<N;i++){
            for(int j=0;j<(N/2);j++){
              int aux = matrix[i][j];
              matrix[i][j] = matrix[i][N-1-j];
              matrix[i][N-1-j] = aux;
            }
          }
          for(int r[] : matrix){
            for(int element : r){
              System.out.print(element+" ");
            }
            System.out.println();
          }

          break;

        case 180:
        for(int count=0;count<2;count++){
            for(int i=0;i<N;i++){
              for(int j=i; j<N; j++){
                int aux = matrix[i][j];
                matrix[i][j] = matrix[j][i];
                matrix[j][i] = aux;
              }
            }
            for(int i=0;i<N;i++){
              for(int j=0;j<(N/2);j++){
                int aux = matrix[i][j];
                matrix[i][j] = matrix[i][N-1-j];
                matrix[i][N-1-j] = aux;
              }
            }
        }
          for(int r[] : matrix){
            for(int element : r){
              System.out.print(element+" ");
            }
            System.out.println();
          }

          break;

        case 270:
        for(int count=0;count<3;count++){
            for(int i=0;i<N;i++){
              for(int j=i; j<N; j++){
                int aux = matrix[i][j];
                matrix[i][j] = matrix[j][i];
                matrix[j][i] = aux;
              }
            }
            for(int i=0;i<N;i++){
              for(int j=0;j<(N/2);j++){
                int aux = matrix[i][j];
                matrix[i][j] = matrix[i][N-1-j];
                matrix[i][N-1-j] = aux;
              }
            }
        }
          for(int r[] : matrix){
            for(int element : r){
              System.out.print(element+" ");
            }
            System.out.println();
          }

          break; 

        case 360:
          for(int r[] : matrix){
            for(int element : r){
              System.out.print(element+" ");
            }
            System.out.println();
          }        

          break;

        default:
          System.out.println("Grau inválido.");
      }

    }
  }