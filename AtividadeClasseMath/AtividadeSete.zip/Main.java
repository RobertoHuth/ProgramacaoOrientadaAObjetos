import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        var scn = new Scanner(System.in);
        double x;
        double y;

        do {
            System.out.println("Dê o valor de x [−15, −5]:");
            x = scn.nextDouble();
        } while(x < -15 || x > -5);

        do {
            System.out.println("Dê o valor de y [−3, 3]:");
            y = scn.nextDouble();
        } while(y < -3 || y > 3);

        double result = 100 * Math.sqrt(Math.abs(y - 0.01 * Math.pow(x, 2))) + 0.01 * Math.abs(x + 10);

        System.out.println("O resultado é " + result);
        scn.close();
    }
}