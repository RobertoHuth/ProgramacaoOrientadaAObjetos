import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);

        double x;
        double y;
        double z;

        System.out.print("Informe o valor de x: ");
        x = scn.nextDouble();

        System.out.print("Informe o valor de y: ");
        y = scn.nextDouble();

        System.out.print("Informe o valor de z: ");
        z = scn.nextDouble();

        double result = 4 * (Math.pow((Math.pow(x, 2) + Math.pow(y, 2) - x*y), 0.75) + z)/3;

        System.out.println("O resultado é: " + result);
        scn.close();
    }

}